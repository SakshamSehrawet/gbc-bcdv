pb = require('./progress-bar')
pb.startProgress()