const calculator = require('./calculator')

console.log(calculator.mulitplyTwoNumbers(2,5),calculator.evenDoubler(4))